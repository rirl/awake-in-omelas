#!/usr/bin/env bash

docker run -i --rm   --mount type=bind,src="$(pwd)",dst=/workspace/awake-in-omelas,readonly   mcp/filesystem   /workspace/awake-in-omelas
